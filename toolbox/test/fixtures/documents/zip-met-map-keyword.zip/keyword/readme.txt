Een gewone zip met een map keyword.
